class Add_1
  def sum1(a,b)
    return a+b
  end
end
a=Add_1.new
puts a.sum1(3,4)
